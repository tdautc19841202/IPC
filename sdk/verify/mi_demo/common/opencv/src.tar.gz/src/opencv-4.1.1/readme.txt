export PATH=/tools/toolchain/gcc-arm-8.2-2018.08-x86_64-arm-linux-gnueabihf/bin/:$PATH
export ARCH=arm
export CROSS_COMPILE=arm-linux-gnueabihf-


cd platforms/linux
mkdir -p build_hardfp
cd build_hardfp
cmake -DCMAKE_TOOLCHAIN_FILE=../arm-gnueabi.toolchain.cmake -DCMAKE_BUILD_TYPE=Release     -DENABLE_NEON=ON    ../../..
make 
make install

