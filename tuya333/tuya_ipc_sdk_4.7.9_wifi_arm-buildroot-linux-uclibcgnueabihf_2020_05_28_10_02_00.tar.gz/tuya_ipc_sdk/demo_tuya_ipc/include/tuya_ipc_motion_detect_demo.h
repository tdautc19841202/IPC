#ifndef __TUYA_MD_DEMO_H_
#define __TUYA_MD_DEMO_H_
#include <stdio.h>

void *thread_md_proc(void *arg);
OPERATE_RET TUYA_APP_Enable_AI_Detect();

#endif
